"""
Entity detection: two-layer approach
  Layer 1 – Regex   for structured data (INN, OGRN, phone, email …)
  Layer 2 – Natasha for unstructured data (names in all cases, company names)

Natasha is loaded lazily in a background thread on first import.
"""

import re
import threading
from dataclasses import dataclass
from typing import List, Tuple

# ─────────────────────────────────────────────────────────────────────────────
# Data class
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Entity:
    original:      str   # exact text found in the document
    canonical:     str   # normalised (nominative case for names)
    entity_type:   str   # ИНН, ФИО, etc.
    start:         int
    end:           int


# ─────────────────────────────────────────────────────────────────────────────
# Regex patterns
# Each entry: (compiled_pattern, value_group_or_0_for_whole_match)
# ─────────────────────────────────────────────────────────────────────────────

def _p(pattern):
    return re.compile(pattern, re.IGNORECASE | re.UNICODE)


REGEX_PATTERNS: List[Tuple[str, List[Tuple]]] = [
    ('ИНН', [
        (_p(r'(?:ИНН\s*[:№\s]\s*)(\d{10}|\d{12})\b'), 1),
        (_p(r'\bИНН\s+(\d{10}|\d{12})\b'), 1),
    ]),
    ('ОГРН', [
        (_p(r'(?:ОГРНИП\s*[:№\s]\s*)(\d{15})\b'), 1),
        (_p(r'(?:ОГРН\s*[:№\s]\s*)(\d{13})\b'),   1),
    ]),
    ('КПП', [
        (_p(r'(?:КПП\s*[:№\s]\s*)(\d{9})\b'), 1),
    ]),
    ('РС', [
        (_p(r'(?:р\s*/\s*с\.?|расч[её]тн\w+\s+сч[её]т\w*)\s*[:№\s]\s*(\d{20})\b'), 1),
    ]),
    ('КС', [
        (_p(r'(?:к\s*/\s*с\.?|корр?\.\s*сч[её]т\w*|корреспондентск\w+\s+сч[её]т\w*)\s*[:№\s]\s*(\d{20})\b'), 1),
    ]),
    ('БИК', [
        (_p(r'(?:БИК\s*[:№\s]\s*)(\d{9})\b'), 1),
    ]),
    ('СНИЛС', [
        (_p(r'\b(\d{3}-\d{3}-\d{3}\s+\d{2})\b'), 1),
        (_p(r'(?:СНИЛС\s*[:№\s]\s*)(\d{11})\b'),  1),
    ]),
    ('ПАСПОРТ', [
        # «паспорт серии 45 07 номер 123456» or «паспорт 4507 123456»
        (_p(r'(?:паспорт\w*\s+(?:серии?\s+)?)(\d{2}\s*\d{2})\s+(?:(?:номер|№)\s+)?(\d{6})\b'), 0),
        (_p(r'(?:серия\s+)(\d{2}\s+\d{2})[,;\s]+(?:номер|№)\s+(\d{6})\b'), 0),
    ]),
    ('ТЕЛЕФОН', [
        # с ключевым словом
        (_p(r'(?:тел[ефон.:\s]*|моб\.?\s*[:\s]|факс\s*[:\s])(\+?[78][\s\-\(]?\d{3}[\s\-\)]\s*\d{3}[\s\-]\d{2}[\s\-]\d{2})\b'), 1),
        # +7 без слова
        (_p(r'(?<!\d)(\+7[\s\-\(]?\d{3}[\s\-\)]?\s*\d{3}[\s\-]\d{2}[\s\-]\d{2})\b'), 1),
    ]),
    ('EMAIL', [
        (_p(r'\b([A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,})\b'), 1),
    ]),
    ('SWIFT', [
        (_p(r'(?:SWIFT(?:\s*[-:]\s*|\s+))([A-Z]{4}[A-Z]{2}[A-Z0-9]{2}(?:[A-Z0-9]{3})?)\b'), 1),
    ]),
]


def extract_regex_entities(text: str) -> List[Entity]:
    entities   = []
    used_spans = []   # list of (start, end) already claimed

    for entity_type, patterns in REGEX_PATTERNS:
        for pat, grp in patterns:
            for m in pat.finditer(text):
                if grp == 0:
                    value = m.group(0)
                    s, e  = m.start(), m.end()
                else:
                    # may have multiple groups (passport)
                    groups = [g for g in m.groups() if g]
                    if not groups:
                        continue
                    value = ' '.join(groups)
                    # span that covers all captured groups
                    s = m.start(next(i+1 for i, g in enumerate(m.groups()) if g))
                    e = m.end(max(i+1 for i, g in enumerate(m.groups()) if g))

                value = value.strip()
                if not value:
                    continue

                # skip if overlaps with already-found entity
                if any(not (e <= us or s >= ue) for us, ue in used_spans):
                    continue

                entities.append(Entity(value, value, entity_type, s, e))
                used_spans.append((s, e))

    return entities


# ─────────────────────────────────────────────────────────────────────────────
# Natasha NER  (loaded once in a background thread)
# ─────────────────────────────────────────────────────────────────────────────

_lock        = threading.Lock()
_ner_ready   = False
_ner_loading = False
_ner_error   = None

_segmenter   = None
_morph_vocab = None
_morph_tagger= None
_ner_tagger  = None


def get_ner_status() -> dict:
    return {'ready': _ner_ready, 'loading': _ner_loading,
            'error': _ner_error}


def _do_load():
    global _ner_ready, _ner_loading, _ner_error
    global _segmenter, _morph_vocab, _morph_tagger, _ner_tagger
    try:
        from natasha import (Segmenter, MorphVocab, NewsEmbedding,
                             NewsMorphTagger, NewsNERTagger)
        _segmenter    = Segmenter()
        _morph_vocab  = MorphVocab()
        emb           = NewsEmbedding()
        _morph_tagger = NewsMorphTagger(emb)
        _ner_tagger   = NewsNERTagger(emb)
        _ner_ready    = True
    except Exception as ex:
        _ner_error = str(ex)
    finally:
        _ner_loading = False


def start_ner_loading():
    """Call once at app startup – loads NER in background."""
    global _ner_loading
    with _lock:
        if _ner_ready or _ner_loading:
            return
        _ner_loading = True
    t = threading.Thread(target=_do_load, daemon=True)
    t.start()


def extract_ner_entities(text: str,
                         existing_spans: List[Tuple[int, int]]) -> List[Entity]:
    if not _ner_ready:
        return []

    from natasha import Doc
    try:
        doc = Doc(text)
        doc.segment(_segmenter)
        doc.tag_morph(_morph_tagger)
        doc.tag_ner(_ner_tagger)
    except Exception:
        return []

    entities = []
    for span in doc.spans:
        if span.type not in ('PER', 'ORG'):
            continue

        etype = 'ФИО' if span.type == 'PER' else 'ЮЛ'
        s, e  = span.start, span.stop

        if any(not (e <= us or s >= ue) for us, ue in existing_spans):
            continue

        try:
            span.normalize(_morph_vocab)
            canon = span.normal
        except Exception:
            canon = span.text

        entities.append(Entity(span.text, canon, etype, s, e))

    return entities


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def extract_all_entities(text: str) -> List[Entity]:
    regex_ents   = extract_regex_entities(text)
    regex_spans  = [(e.start, e.end) for e in regex_ents]
    ner_ents     = extract_ner_entities(text, regex_spans)

    all_ents = regex_ents + ner_ents
    all_ents.sort(key=lambda e: e.start)
    return all_ents


def build_replacements(entities: List[Entity],
                       db_path, session_id: str) -> dict:
    """Return {original_text: token}.  Same canonical → same token."""
    from core.db import get_or_create_token
    result = {}
    for ent in entities:
        token = get_or_create_token(db_path, session_id,
                                    ent.canonical, ent.entity_type)
        result.setdefault(ent.original, token)
    return result


def apply_replacements(text: str, replacements: dict) -> str:
    if not replacements:
        return text
    for orig, token in sorted(replacements.items(), key=lambda x: -len(x[0])):
        text = text.replace(orig, token)
    return text


def apply_reverse(text: str, reverse_map: dict) -> str:
    if not reverse_map:
        return text
    for token, orig in sorted(reverse_map.items(), key=lambda x: -len(x[0])):
        text = text.replace(token, orig)
    return text
