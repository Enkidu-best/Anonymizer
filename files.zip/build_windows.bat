@echo off
echo =========================================
echo  Anonymizer — сборка Windows (.exe)
echo =========================================

REM Устанавливаем зависимости
pip install -r requirements.txt
pip install pyinstaller

REM Сборка одного исполняемого файла
pyinstaller ^
  --onefile ^
  --windowed ^
  --name Anonymizer ^
  --add-data "static;static" ^
  --add-data "core;core" ^
  --hidden-import=natasha ^
  --hidden-import=pymorphy2 ^
  --hidden-import=pymorphy2.tagset ^
  --hidden-import=pymorphy2.analyzer ^
  --hidden-import=docx ^
  --hidden-import=fitz ^
  --hidden-import=pdfplumber ^
  --hidden-import=pdfminer ^
  --hidden-import=pdfminer.high_level ^
  --hidden-import=openpyxl ^
  --hidden-import=striprtf ^
  --hidden-import=striprtf.striprtf ^
  --hidden-import=flask ^
  --hidden-import=flask_cors ^
  --hidden-import=werkzeug ^
  --hidden-import=jinja2 ^
  --hidden-import=click ^
  --collect-all natasha ^
  --collect-all pymorphy2 ^
  --collect-all navec ^
  --collect-all razdel ^
  app.py

echo.
echo =========================================
echo  Готово!  dist\Anonymizer.exe
echo  Скопируйте файл в любую папку и запустите.
echo  При первом запуске откроется браузер.
echo =========================================
pause
