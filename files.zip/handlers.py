"""
File format handlers.
Each handler receives input_path, output_path, and a replacements dict.
"""
import os
import sys
from pathlib import Path
from typing import Union

ALLOWED_EXTENSIONS = {'.txt', '.docx', '.pdf', '.xlsx', '.rtf'}


# ─────────────────────────────────────────────────────────────────────────────
# Validation
# ─────────────────────────────────────────────────────────────────────────────

def validate_file(filepath: Path):
    """Return (ok: bool, error: str)."""
    ext = filepath.suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        supported = ', '.join(sorted(ALLOWED_EXTENSIONS))
        return False, f'Формат «{ext}» не поддерживается. Поддерживаются: {supported}'

    if ext == '.pdf' and not _pdf_has_text_layer(filepath):
        return False, ('PDF не содержит текстового слоя (возможно скан-копия). '
                       'Обработка невозможна без OCR.')
    return True, ''


def _pdf_has_text_layer(filepath: Path) -> bool:
    try:
        import fitz
        doc = fitz.open(str(filepath))
        return any(page.get_text().strip() for page in doc)
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

def process_uploaded_file(input_path: Path, output_dir: Path,
                          session_id: str, db_path, mode: str) -> dict:
    valid, err = validate_file(input_path)
    if not valid:
        raise ValueError(err)

    ext         = input_path.suffix.lower()
    prefix      = 'anon' if mode == 'anonymize' else 'deanon'
    output_name = f'{prefix}_{input_path.name}'
    output_path = output_dir / output_name

    if mode == 'anonymize':
        result = _anonymize(input_path, output_path, ext, session_id, db_path)
    else:
        result = _deanonymize(input_path, output_path, ext, session_id, db_path)

    result['output_filename'] = output_name
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Anonymize dispatcher
# ─────────────────────────────────────────────────────────────────────────────

def _anonymize(input_path, output_path, ext, session_id, db_path):
    from core.anonymizer import (extract_all_entities, build_replacements,
                                  apply_replacements)

    if ext == '.txt':
        text     = input_path.read_text(encoding='utf-8', errors='replace')
        ents     = extract_all_entities(text)
        reps     = build_replacements(ents, db_path, session_id)
        output_path.write_text(apply_replacements(text, reps), encoding='utf-8')
        return {'entities_found': len(ents)}

    if ext == '.docx':
        return _anon_docx(input_path, output_path, session_id, db_path)

    if ext == '.pdf':
        return _anon_pdf(input_path, output_path, session_id, db_path)

    if ext == '.xlsx':
        return _anon_xlsx(input_path, output_path, session_id, db_path)

    if ext == '.rtf':
        return _anon_rtf(input_path, output_path, session_id, db_path)

    raise ValueError(f'Unsupported extension: {ext}')


# ─────────────────────────────────────────────────────────────────────────────
# Deanonymize dispatcher
# ─────────────────────────────────────────────────────────────────────────────

def _deanonymize(input_path, output_path, ext, session_id, db_path):
    from core.db       import get_reverse_mappings
    from core.anonymizer import apply_reverse

    rev = get_reverse_mappings(db_path, session_id)

    if ext == '.txt':
        text = input_path.read_text(encoding='utf-8', errors='replace')
        output_path.write_text(apply_reverse(text, rev), encoding='utf-8')
        return {}

    if ext == '.docx':
        return _deanon_docx(input_path, output_path, rev)

    if ext == '.pdf':
        return _deanon_pdf(input_path, output_path, rev, output_path)

    if ext == '.xlsx':
        return _deanon_xlsx(input_path, output_path, rev)

    if ext == '.rtf':
        return _deanon_rtf(input_path, output_path, rev)

    raise ValueError(f'Unsupported extension: {ext}')


# ─────────────────────────────────────────────────────────────────────────────
# DOCX helpers
# ─────────────────────────────────────────────────────────────────────────────

def _collect_docx_text(doc) -> str:
    parts = [p.text for p in doc.paragraphs]
    for tbl in doc.tables:
        for row in tbl.rows:
            for cell in row.cells:
                parts += [p.text for p in cell.paragraphs]
    return '\n'.join(parts)


def _replace_para(para, replacements: dict):
    """Replace text in a paragraph, handling cross-run spans."""
    if not replacements or not para.text.strip():
        return

    sorted_reps = sorted(replacements.items(), key=lambda x: -len(x[0]))

    # Pass 1: per-run (handles ~90 % of cases)
    for old, new in sorted_reps:
        for run in para.runs:
            if old in run.text:
                run.text = run.text.replace(old, new)

    # Pass 2: cross-run (entity spans formatting boundary)
    for old, new in sorted_reps:
        if old not in para.text:
            continue
        _cross_run_replace(para, old, new)


def _cross_run_replace(para, old: str, new: str):
    runs = para.runs
    if not runs:
        return
    full = ''.join(r.text for r in runs)
    if old not in full:
        return

    # Build run boundaries
    pos, spans = 0, []
    for r in runs:
        spans.append((pos, pos + len(r.text)))
        pos += len(r.text)

    new_full = full.replace(old, new)

    # Put all text in the first run, clear the rest
    # (loses intra-paragraph bold/italic of the replaced text,
    #  but preserves paragraph-level and surrounding formatting)
    runs[0].text = new_full
    for r in runs[1:]:
        r.text = ''


def _iter_all_paras(doc):
    yield from doc.paragraphs
    for tbl in doc.tables:
        for row in tbl.rows:
            for cell in row.cells:
                yield from cell.paragraphs
    for section in doc.sections:
        try:
            yield from section.header.paragraphs
            yield from section.footer.paragraphs
        except Exception:
            pass


def _anon_docx(input_path, output_path, session_id, db_path):
    from docx import Document
    from core.anonymizer import (extract_all_entities, build_replacements)

    doc      = Document(str(input_path))
    full     = _collect_docx_text(doc)
    ents     = extract_all_entities(full)
    reps     = build_replacements(ents, db_path, session_id)

    if reps:
        for para in _iter_all_paras(doc):
            _replace_para(para, reps)

    doc.save(str(output_path))
    return {'entities_found': len(ents)}


def _deanon_docx(input_path, output_path, rev):
    from docx import Document

    doc = Document(str(input_path))
    if rev:
        for para in _iter_all_paras(doc):
            _replace_para(para, rev)
    doc.save(str(output_path))
    return {}


# ─────────────────────────────────────────────────────────────────────────────
# PDF helpers
# ─────────────────────────────────────────────────────────────────────────────

def _anon_pdf(input_path, output_path, session_id, db_path):
    import fitz
    from core.anonymizer import extract_all_entities, build_replacements

    doc      = fitz.open(str(input_path))
    all_text = '\n'.join(p.get_text() for p in doc)
    ents     = extract_all_entities(all_text)
    reps     = build_replacements(ents, db_path, session_id)

    if reps:
        sorted_reps = sorted(reps.items(), key=lambda x: -len(x[0]))
        for page in doc:
            for orig, token in sorted_reps:
                for rect in page.search_for(orig):
                    # token is ASCII (e.g. FIO_1) — Helvetica is fine
                    page.add_redact_annot(rect, text=token,
                                         fontsize=max(6, rect.height * 0.75),
                                         fill=(0.95, 0.95, 1.0))
            page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_NONE)

    doc.save(str(output_path), garbage=4, deflate=True)
    return {'entities_found': len(ents)}


def _deanon_pdf(input_path, output_path, rev, original_output_path):
    """
    Deanonymization of PDF.
    Tokens (ASCII: FIO_1 etc.) are replaced with original values.
    Because original values may contain Cyrillic, we use the system font
    when available; otherwise we produce a .txt file with a clear notice.
    """
    import fitz
    from core.anonymizer import apply_reverse

    doc = fitz.open(str(input_path))

    # Try to find a system font that supports Cyrillic
    cyrillic_font = _find_cyrillic_font()

    if cyrillic_font:
        if rev:
            sorted_rev = sorted(rev.items(), key=lambda x: -len(x[0]))
            for page in doc:
                for token, orig in sorted_rev:
                    for rect in page.search_for(token):
                        kw = {'fontsize': max(6, rect.height * 0.75),
                              'fill': (1.0, 1.0, 0.85)}
                        if cyrillic_font:
                            kw['fontfile'] = cyrillic_font
                        page.add_redact_annot(rect, text=orig, **kw)
                page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_NONE)
        doc.save(str(output_path), garbage=4, deflate=True)
    else:
        # Fallback: extract text, replace, save as .txt
        all_text = '\n'.join(p.get_text() for p in doc)
        restored  = apply_reverse(all_text, rev)
        txt_path  = output_path.with_suffix('.txt')
        txt_path.write_text(
            '=== ДЕАНОНИМИЗИРОВАННЫЙ ТЕКСТ (PDF → TXT, шрифт с кириллицей не найден) ===\n\n'
            + restored,
            encoding='utf-8'
        )
        # rename so the output_filename matches
        output_path.with_suffix('.txt').rename(output_path)

    return {}


def _find_cyrillic_font() -> str | None:
    candidates = []
    if sys.platform == 'win32':
        candidates = [
            r'C:\Windows\Fonts\arial.ttf',
            r'C:\Windows\Fonts\calibri.ttf',
            r'C:\Windows\Fonts\times.ttf',
            r'C:\Windows\Fonts\cour.ttf',
        ]
    elif sys.platform == 'darwin':
        candidates = [
            '/Library/Fonts/Arial.ttf',
            '/System/Library/Fonts/Supplemental/Arial.ttf',
            '/System/Library/Fonts/Helvetica.ttc',
        ]
    else:
        candidates = [
            '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf',
            '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
        ]
    for p in candidates:
        if os.path.exists(p):
            return p
    return None


# ─────────────────────────────────────────────────────────────────────────────
# XLSX helpers
# ─────────────────────────────────────────────────────────────────────────────

def _anon_xlsx(input_path, output_path, session_id, db_path):
    from openpyxl import load_workbook
    from core.anonymizer import extract_all_entities, build_replacements, apply_replacements

    wb   = load_workbook(str(input_path))
    text = '\n'.join(
        str(cell.value)
        for ws in wb.worksheets
        for row in ws.iter_rows()
        for cell in row
        if isinstance(cell.value, str) and cell.value.strip()
    )
    ents = extract_all_entities(text)
    reps = build_replacements(ents, db_path, session_id)

    if reps:
        for ws in wb.worksheets:
            for row in ws.iter_rows():
                for cell in row:
                    if isinstance(cell.value, str):
                        cell.value = apply_replacements(cell.value, reps)

    wb.save(str(output_path))
    return {'entities_found': len(ents)}


def _deanon_xlsx(input_path, output_path, rev):
    from openpyxl import load_workbook
    from core.anonymizer import apply_reverse

    wb = load_workbook(str(input_path))
    if rev:
        for ws in wb.worksheets:
            for row in ws.iter_rows():
                for cell in row:
                    if isinstance(cell.value, str):
                        cell.value = apply_reverse(cell.value, rev)
    wb.save(str(output_path))
    return {}


# ─────────────────────────────────────────────────────────────────────────────
# RTF helpers  (work on raw RTF bytes — preserves structure but simple)
# ─────────────────────────────────────────────────────────────────────────────

def _extract_rtf_plain(filepath: Path) -> str:
    try:
        from striprtf.striprtf import rtf_to_text
        raw = filepath.read_bytes().decode('utf-8', errors='replace')
        return rtf_to_text(raw)
    except Exception:
        return ''


def _anon_rtf(input_path, output_path, session_id, db_path):
    from core.anonymizer import extract_all_entities, build_replacements, apply_replacements

    plain = _extract_rtf_plain(input_path)
    ents  = extract_all_entities(plain)
    reps  = build_replacements(ents, db_path, session_id)

    # Apply replacements to the raw RTF content (works for plain text spans)
    raw = input_path.read_bytes().decode('utf-8', errors='replace')
    new = apply_replacements(raw, reps)
    output_path.write_text(new, encoding='utf-8')
    return {'entities_found': len(ents)}


def _deanon_rtf(input_path, output_path, rev):
    from core.anonymizer import apply_reverse

    raw = input_path.read_bytes().decode('utf-8', errors='replace')
    output_path.write_text(apply_reverse(raw, rev), encoding='utf-8')
    return {}
